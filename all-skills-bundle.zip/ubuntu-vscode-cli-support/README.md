# ubuntu-vscode-cli-support

VSCodeとUbuntu（WSL・VM・実機）でのコマンド学習、実務での利用、トラブル切り分けを支援するClaude Skillです。IT研修講師の視点で、公式ドキュメントを根拠に案内します。

## 含まれるファイル
- `SKILL.md`：学習・実務・トラブル対応の手順、安全上の注意

## インストール方法
1. フォルダ `ubuntu-vscode-cli-support` を Claude のスキルフォルダに配置します。
   - Claude Code：`~/.claude/skills/` または プロジェクトの `.claude/skills/`
   - Claude.ai：スキルとしてZipをアップロード
2. 「Ubuntuのコマンドを教えて」「VSCodeのターミナルが動かない」などと依頼すると起動します。

## 使い方の例
- 学習：「ls と cd を初心者向けに、練習問題つきで教えて」
- 実務：「ログフォルダを日付つきでバックアップする手順を、安全確認つきで」
- トラブル：「`Permission denied` が出た。エラー文はこれ」（エラー文は全文を貼る）

## 参照する公式情報
- Ubuntu 公式ドキュメント：ubuntu.com/server/docs、ubuntu.com/desktop
- VSCode 公式ドキュメント：code.visualstudio.com/docs
- WSL 公式ドキュメント：learn.microsoft.com/windows/wsl
- Linux man ページ：`man コマンド名`

## 注意
- コマンドの仕様はバージョンで変わることがあります。実行前に `man` や `--help` で確認してください。
- 削除・権限変更を伴う操作は、必ず対象とバックアップを確認してから実行してください。
- パスワードや秘密鍵をチャットに貼らないでください。
