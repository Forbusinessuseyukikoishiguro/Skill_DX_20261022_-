# claude-code-multiagent-support

Claude Codeで複数のエージェント（サブエージェント）に担当を割り当て、並列処理で作業を進めるための支援Claude Skillと、ひな形一式です。

## 含まれるファイル
- `SKILL.md`：担当決め、並列化の判定、衝突対策、統合の手順
- `templates/task-brief.md`：依頼書（担当・入出力・完了条件）
- `templates/ownership-table.md`：ファイルの持ち主を決める表と衝突チェック
- `templates/agent-role-template.md`：サブエージェント定義のひな形（`.claude/agents/` に置く）

## インストール方法
1. フォルダ `claude-code-multiagent-support` を Claude のスキルフォルダに配置します。
   - `~/.claude/skills/` または プロジェクトの `.claude/skills/`
2. 「マルチエージェントで並列に作りたい」と依頼すると起動します。

## 使い方
1. 作業の目的を1文で伝えます。
2. Claude が作業を分解し、並列化の判定と担当案を出します。
3. `task-brief.md` と `ownership-table.md` を埋めて確定します。
4. 担当ごとに `agent-role-template.md` をもとにサブエージェント定義を作成します。
5. 完了後、統合担当が完了条件と照合し、テストを1回まとめて実行します。

## 運用の注意
- 最初は2〜3担当から始めてください。
- 同じファイルを複数の担当に編集させないでください。
- サブエージェントの定義形式は、公式ドキュメント（code.claude.com/docs）で最新の仕様を確認してください。
- 機密情報は依頼書に書かないでください。
