# 公式情報源の登録一覧

手順を案内する前に、ここから該当の公式ページを選んで確認する。URLは確認時点のもので、変わることがある。

## Claude Code
- サブエージェント：https://code.claude.com/docs/en/subagents
- 旧URL（リダイレクトの可能性あり）：https://docs.anthropic.com/en/docs/claude-code/sub-agents
- 確認コマンド：`/agents`、`claude agents`、`/mcp`、`claude mcp list`、`/doctor`

## Playwright MCP（Microsoft）
- 公式リポジトリ：https://github.com/microsoft/playwright-mcp
- インストール例（README記載）：`claude mcp add playwright npx @playwright/mcp@latest`、VS Codeは `code --add-mcp` の例あり
- 注意：Windowsでは `cmd /c` ラッパーが必要という警告が出る場合がある（Claude Codeの `/doctor` で確認）

## VSCode
- 公式ドキュメント：https://code.visualstudio.com/docs
- ターミナル：https://code.visualstudio.com/docs/terminal/basics

## WSL
- 公式ドキュメント：https://learn.microsoft.com/windows/wsl

## Ubuntu
- サーバー：https://ubuntu.com/server/docs
- デスクトップ：https://ubuntu.com/desktop

## Linuxコマンド
- マニュアル：`man コマンド名`、`コマンド --help`

## Node.js
- 公式サイト：https://nodejs.org

## WCAG（コントラスト基準）
- 公式：https://www.w3.org/TR/WCAG22/

## ISO
- 規格の概要は ISO 公式サイト（iso.org）で確認。全文は有償のため、引用は公開情報の範囲に限る
