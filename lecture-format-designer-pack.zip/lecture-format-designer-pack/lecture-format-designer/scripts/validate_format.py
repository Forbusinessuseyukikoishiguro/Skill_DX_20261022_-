#!/usr/bin/env python3
"""講義フォーマット別の構成検査。 使い方: python validate_format.py design.yaml [--json out.json]
format: slope8 | workshop | two_part_lecture | udemy
FAIL=型の必須要素の欠落 / WARN=設計上の目安からの逸脱（理由を書けば残してよい）
"""
import argparse, json, sys
import yaml

BANNED = ["理解する", "知る", "把握する", "学ぶ", "意識する", "心がける", "分かる", "わかる", "習得する"]
BLOCKS8 = ["導入", "概要", "要点", "説明", "図解", "実践", "質問", "対応"]
R = []
def add(l, c, m): R.append((l, c, m))

def common(d):
    meta = d.get("meta") or {}
    if not meta.get("title"): add("FAIL", "META", "meta.title が無い")
    if not meta.get("audience"): add("FAIL", "META", "meta.audience（対象者）が無い")
    objs = d.get("objectives") or []
    if not objs and d.get("format") != "udemy": add("FAIL", "OBJ", "objectives が空")
    for o in objs:
        t = o.get("text", "") + o.get("verb", "")
        if any(b in t for b in BANNED): add("FAIL", "OBJ-VERB", f"{o.get('id')}: 観察不能な動詞を含む")
        if not o.get("verb"): add("FAIL", "OBJ-VERB", f"{o.get('id')}: verb が未記入")
    if "assumptions" not in d: add("WARN", "ASSUMP", "assumptions キーが無い（仮定が無ければ空配列で明示）")

def slope8(d):
    ch = d.get("chapters") or []
    meta = d.get("meta") or {}
    if any(False in c or "no" in c for c in ch):
        add("FAIL", "KEY", "章番号キーに no は使えません（YAMLでfalse扱いになる）。ch を使ってください")
        return
    n = [c for c in ch if c.get("phase") != "bridge"]
    if len(n) != 8: add("WARN", "CH-COUNT", f"章数{len(n)}（標準は8。増減する場合は理由を明記）")
    if len(ch) < 6: add("FAIL", "CH-COUNT", "章が6未満")
    order = {"knowledge": 0, "bridge": 1, "practice": 2}
    seq = [order.get(c.get("phase"), -1) for c in ch]
    if -1 in seq: add("FAIL", "PHASE", "phase は knowledge|bridge|practice")
    elif seq != sorted(seq): add("FAIL", "PHASE-ORDER", "知識編→橋渡し→実践編の順になっていない")
    know = [c for c in ch if c.get("phase") == "knowledge"]; prac = [c for c in ch if c.get("phase") == "practice"]
    if not know or not prac: add("FAIL", "PHASE", "知識編と実践編の両方が必要")
    if not any(c.get("phase") == "bridge" for c in ch): add("FAIL", "BRIDGE", "橋渡しが無い（知識→実践の伏線回収点）")
    cl = [c for c in ch if c.get("climax")]
    if len(cl) != 1: add("FAIL", "CLIMAX", f"山場(climax:true)が{len(cl)}個（ちょうど1つ）")
    elif cl[0].get("phase") != "knowledge": add("WARN", "CLIMAX-PHASE", "山場が知識編にない")
    elif know and cl[0].get("difficulty", 0) < max(c.get("difficulty", 0) for c in know): add("WARN", "CLIMAX-DIFF", "山場が知識編で最難ではない")
    if not any(c.get("climax_practice") for c in prac): add("FAIL", "CLIMAX-PRACTICE", "山場の概念を自分で表現する実践章（climax_practice）が無い")
    if prac and not any(c.get("first_win") for c in prac): add("WARN", "FIRST-WIN", "最初の小さな成功体験(first_win)が無い")
    for c in ch:
        g = c.get("goal", "")
        if not g: add("FAIL", "GOAL", f"章{c.get('ch')}: 「今日のゴール」が無い")
        elif len(g) > 60 or g.count("。") > 1: add("WARN", "GOAL-LONG", f"章{c.get('ch')}: ゴールは一文・短く（現在{len(g)}字）")
    for c in know:
        if not c.get("mini_exercise"): add("FAIL", "MINI-EX", f"章{c.get('ch')}: 章末ミニ演習が無い")
        if not c.get("analogy"): add("WARN", "ANALOGY", f"章{c.get('ch')}: たとえ話が無い（たとえ話→実物の順）")
    used = {u for c in prac for u in c.get("uses", [])}
    for c in know:
        if c.get("ch") not in used: add("WARN", "FORESHADOW", f"章{c.get('ch')}: 実践編のどの章でも使われていない（伏線未回収）")
    if any(c.get("difficulty") is None for c in ch): add("WARN", "DIFF", "difficulty(1-5) が未記入の章がある")
    else:
        for ph in ("knowledge", "practice"):  # 同じ編の中で急に下がらないこと（編をまたぐ難易度リセットは設計上自然）
            dif = [c["difficulty"] for c in ch if c.get("phase") == ph and c.get("type") != "review"]
            for a, b in zip(dif, dif[1:]):
                if b < a - 1: add("WARN", "SLOPE", f"{ph}編で難易度が急に下がる箇所がある（{a}→{b}）"); break
    if not any(c.get("type") == "review" for c in ch): add("WARN", "REVIEW", "振り返り＆次のステップ章(type: review)が無い")
    tot = sum(c.get("minutes", 0) for c in ch)
    if tot != meta.get("duration_min"): add("FAIL", "TIME-SUM", f"章の合計{tot}分 ≠ meta.duration_min {meta.get('duration_min')}分")

def workshop(d):
    parts = d.get("parts") or []; ws = d.get("workshop") or {}; meta = d.get("meta") or {}
    kinds = [p.get("kind") for p in parts]
    if "lecture" not in kinds: add("FAIL", "PART", "講義パートが無い")
    if "workshop" not in kinds: add("FAIL", "PART", "ワークショップパートが無い")
    elif "lecture" in kinds and kinds.index("lecture") > kinds.index("workshop"): add("FAIL", "ORDER", "講義がワークショップより後ろにある")
    tot = sum(p.get("minutes", 0) for p in parts)
    if tot != meta.get("duration_min"): add("FAIL", "TIME-SUM", f"パート合計{tot}分 ≠ meta.duration_min {meta.get('duration_min')}分")
    eff = sum(p.get("minutes", 0) for p in parts if p.get("kind") != "break")
    lec = sum(p.get("minutes", 0) for p in parts if p.get("kind") == "lecture")
    wsm = sum(p.get("minutes", 0) for p in parts if p.get("kind") == "workshop")
    if eff and lec / eff > 0.5: add("WARN", "LECTURE-RATIO", f"講義{lec/eff:.0%}（目安は半分以下）")
    if eff and wsm / eff < 0.4: add("WARN", "WS-RATIO", f"ワークショップ{wsm/eff:.0%}（目安は4割以上）")
    for p in parts:
        if p.get("kind") == "lecture" and not p.get("key_points"): add("WARN", "KEYPOINTS", f"{p.get('id')}: 講義の要点(key_points)が無い（WSで使う点を明示）")
    if not ws: add("FAIL", "WS", "workshop セクションが無い"); return
    q = ws.get("theme_question", "")
    if not q: add("FAIL", "THEME", "テーマの問い(theme_question)が無い")
    elif "？" not in q and "?" not in q: add("WARN", "THEME-Q", "テーマが問いの形になっていない")
    if not ws.get("deliverable"): add("FAIL", "DELIV", "成果物(deliverable)が未定義")
    gs = ws.get("group_size")
    if gs is None: add("FAIL", "GROUP", "group_size が無い")
    elif not 3 <= gs <= 6: add("WARN", "GROUP", f"グループ{gs}人（目安3〜6）")
    if len(ws.get("ground_rules", [])) < 3: add("WARN", "RULES", "グラウンドルールは3つ以上")
    if not ws.get("facilitator_roles"): add("WARN", "FACIL", "ファシリテーターの役割が無い")
    lp = {k for p in parts for k in p.get("key_points", [])}
    used = ws.get("uses_lecture_points") or []
    if not used: add("FAIL", "BRIDGE", "前半講義のどの要点をWSで使うか(uses_lecture_points)が無い")
    else:
        for u in used:
            if u not in lp: add("WARN", "BRIDGE-REF", f"uses_lecture_points『{u}』が講義のkey_pointsに無い")
    if "オンライン" in meta.get("mode", "") or "ハイブリッド" in meta.get("mode", ""):
        if not ws.get("tools"): add("WARN", "TOOLS", "オンライン/ハイブリッドなのにツール(tools)が未記入")
    ph = ws.get("phases") or []; modes = [p.get("mode") for p in ph]
    for need, lvl in (("diverge", "FAIL"), ("converge", "FAIL"), ("share", "FAIL"), ("reflect", "FAIL")):
        if need not in modes: add(lvl, "PHASE", f"フェーズ {need} が無い")
    if "diverge" in modes and "converge" in modes and modes.index("diverge") > modes.index("converge"): add("FAIL", "PHASE-ORDER", "収束が発散より前にある")
    if "opening" not in modes: add("WARN", "OPENING", "チェックイン/オープニングが無い")
    for p in ph:
        if not p.get("instruction"): add("FAIL", "INSTR", f"フェーズ『{p.get('name')}』に指示文が無い")
    wtot = sum(p.get("minutes", 0) for p in ph)
    if wsm and wtot != wsm: add("FAIL", "WS-TIME", f"フェーズ合計{wtot}分 ≠ ワークショップパート{wsm}分")
    if modes and modes[-1] != "reflect": add("WARN", "PHASE-END", "振り返りで終わっていない")

def two_part(d):
    parts = d.get("parts") or []; meta = d.get("meta") or {}
    kinds = [p.get("kind") for p in parts]
    if kinds.count("lecture") < 2: add("FAIL", "PART", "講義パートが2つ必要")
    else:
        i1 = kinds.index("lecture"); i2 = len(kinds) - 1 - kinds[::-1].index("lecture")
        mid = kinds[i1 + 1:i2]
        if "checkpoint" not in mid: add("FAIL", "CHECKPOINT", "前後半の間に中間確認(checkpoint)が無い")
        if "break" not in mid: add("WARN", "BREAK", "前後半の間に休憩が無い")
        if not parts[i2].get("builds_on"): add("FAIL", "BUILDS-ON", "後半が前半のどのパートを使うか(builds_on)が無い")
    if "exercise" not in kinds: add("FAIL", "EXERCISE", "演習/ケース(exercise)が最低1回必要")
    if "wrap" not in kinds: add("WARN", "WRAP", "まとめ(wrap)が無い")
    tot = sum(p.get("minutes", 0) for p in parts)
    if tot != meta.get("duration_min"): add("FAIL", "TIME-SUM", f"パート合計{tot}分 ≠ meta.duration_min {meta.get('duration_min')}分")
    eff = sum(p.get("minutes", 0) for p in parts if p.get("kind") != "break")
    lec = sum(p.get("minutes", 0) for p in parts if p.get("kind") == "lecture")
    if eff and lec / eff > 0.7: add("WARN", "LECTURE-RATIO", f"講義{lec/eff:.0%}（目安は7割以下。演習・確認を増やす）")
    objs = {o["id"] for o in d.get("objectives", [])}
    cov = {c for p in parts for c in p.get("covers", [])}
    for o in objs - cov: add("FAIL", "COVER", f"目標{o}を扱うパートが無い")
    run = 0
    for p in parts:
        if p.get("kind") == "lecture":
            run += p.get("minutes", 0)
            if run > 60: add("WARN", "LECTURE-RUN", f"{p.get('id')}: 連続講義{run}分（目安60分以内）")
        else: run = 0

def udemy(d):
    c = d.get("course") or {}
    lo = c.get("learning_outcomes") or []
    if not 3 <= len(lo) <= 8: add("WARN", "OUTCOMES", f"学べること{len(lo)}個（目安3〜8）")
    for o in lo:
        if any(b in o.get("text", "") for b in BANNED): add("FAIL", "OUT-VERB", f"{o.get('id')}: 観察不能な動詞を含む")
    if not c.get("target_learners"): add("WARN", "TARGET", "対象者(target_learners)が無い")
    if not c.get("requirements"): add("WARN", "REQ", "受講要件(requirements)が無い")
    secs = c.get("sections") or []
    if not 3 <= len(secs) <= 6: add("WARN", "SEC-COUNT", f"セクション{len(secs)}（目安3〜6）")
    cov = set(); total = 0; types = []
    for si, s in enumerate(secs, 1):
        lec = s.get("lectures") or []
        if not 2 <= len(lec) <= 5: add("WARN", "LEC-COUNT", f"セクション{si}『{s.get('title')}』: レクチャー{len(lec)}（目安2〜5）")
        if not s.get("practice"): add("FAIL", "SEC-PRACTICE", f"セクション{si}: 末尾の課題/クイズ(practice)が無い")
        for l in lec:
            m = l.get("minutes", 0); total += m; t = l.get("type", "standard"); types.append(t)
            cov |= set(l.get("covers_outcomes", []))
            if not 5 <= m <= 15 and t == "standard": add("WARN", "LEC-LEN", f"『{l.get('title')}』{m}分（目安5〜15分）")
            if t != "standard": continue
            b = l.get("blocks") or {}
            for k in BLOCKS8:
                if k not in b or not b[k]: add("FAIL", "BLOCK", f"『{l.get('title')}』: 8ブロック『{k}』が無い")
            it = (b.get("要点") or {}).get("items", [])
            if "要点" in b and len(it) != 3: add("WARN", "POINTS", f"『{l.get('title')}』: 要点は3つ（現在{len(it)}）")
            ex = (b.get("説明") or {}).get("examples", [])
            if "説明" in b and len(ex) < 2: add("WARN", "EXAMPLES", f"『{l.get('title')}』: 具体例は2つ以上（現在{len(ex)}）")
            el = (b.get("図解") or {}).get("elements")
            if el is not None and el > 10: add("WARN", "DIAGRAM", f"『{l.get('title')}』: 図解{el}要素（10以内）")
    ids = {o["id"] for o in lo}
    for o in ids - cov: add("FAIL", "OUTCOME-COVER", f"学べること{o}を扱うレクチャーが無い")
    if "intro" not in types: add("WARN", "INTRO", "導入レクチャー(type: intro)が無い")
    if "outro" not in types: add("WARN", "OUTRO", "まとめレクチャー(type: outro)が無い")
    dm = (d.get("meta") or {}).get("duration_min")
    if dm and dm != total: add("FAIL", "TIME-SUM", f"レクチャー合計{total}分 ≠ meta.duration_min {dm}分")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("yaml"); ap.add_argument("--json")
    a = ap.parse_args()
    d = yaml.safe_load(open(a.yaml, encoding="utf-8"))
    f = d.get("format")
    fn = {"slope8": slope8, "workshop": workshop, "two_part_lecture": two_part, "udemy": udemy}.get(f)
    if not fn: sys.exit(f"format は slope8 | workshop | two_part_lecture | udemy のいずれか（現在: {f}）")
    common(d); fn(d)
    c = {k: sum(1 for r in R if r[0] == k) for k in ("FAIL", "WARN")}
    for lvl, code, msg in sorted(R, key=lambda r: r[0] != "FAIL"): print(f"[{lvl}] {code}: {msg}")
    print(f"\n型: {f}  結果: FAIL={c['FAIL']} WARN={c['WARN']} ->", "PASS（FAILなし）" if not c["FAIL"] else "要修正")
    if a.json: json.dump([{"level": l, "code": c_, "msg": m} for l, c_, m in R], open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    sys.exit(1 if c["FAIL"] else 0)

if __name__ == "__main__":
    main()
