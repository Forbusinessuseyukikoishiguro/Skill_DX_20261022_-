# playwright-mcp-setup-windows-vscode

Windows×VSCode環境で Playwright MCP を導入し、AIからブラウザ操作できるようにする支援Claude Skillです。

## 含まれるファイル
- `SKILL.md`：導入手順、動作確認、トラブル対応、運用上の注意

## インストール方法
1. フォルダ `playwright-mcp-setup-windows-vscode` を Claude のスキルフォルダに配置します。
   - Claude Code：`%USERPROFILE%\.claude\skills\`
   - プロジェクト単位：`.claude\skills\`
2. 「Playwright MCPを入れて」と依頼すると起動します。

## 前提
- Windows 10/11
- Node.js（LTS推奨）
- VSCode
- Claude Code（Claude Codeで使う場合）

## 導入の流れ
1. Node.js とバージョンを確認
2. Claude Code なら `claude mcp add` で登録、VSCode なら `.vscode/mcp.json` を作成
3. `npx playwright install chromium` でブラウザを準備
4. 「example.com の見出しを教えて」で動作確認

## 注意
- コマンドやオプションは変わることがあります。最新の仕様は公式README（github.com/microsoft/playwright-mcp）で確認してください。
- ログイン状態が残るため、共有PCでは作業後にセッションを整理してください。
- パスワードや個人情報はプロンプトに書かないでください。
