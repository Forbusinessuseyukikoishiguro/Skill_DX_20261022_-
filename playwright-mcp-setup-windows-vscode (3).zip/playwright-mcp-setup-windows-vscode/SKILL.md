---
name: playwright-mcp-setup-windows-vscode
description: Windows×VSCodeでPlaywright MCP（@playwright/mcp）を導入・動作確認し、AIからブラウザ操作を使えるようにする支援スキル。「Playwright MCPを入れて」「ブラウザ自動化を設定」「Playwright MCPが動かない」「mcp.jsonを作って」「Claude CodeでWeb操作を有効に」などで必ず使うこと。
---

# Playwright MCP 導入支援（Windows × VSCode）

## 役割
Windows＋VSCode環境で、Playwright MCPを「入れる → 登録する → 1回動かして確認する」までを、つまずきなく案内する。初心者でも手順どおりに進められることを優先する。

## 基本原則
1. **確認しながら進める**：1ステップ終わるごとに、確認コマンドの結果を見てから次へ進む。
2. **Windows固有の罠を先に潰す**：`npx` は Windows では `cmd /c` 経由で呼ぶ必要がある場合が多い。最初からこの形で案内する。
3. **破壊的操作をしない**：既存の設定ファイルは上書きせず、差分を示してから追記する。
4. **根拠を明示する**：出典は公式README（https://github.com/microsoft/playwright-mcp）。`official-source-first` のルールに従い、確認日と版を添える。`@latest` の挙動は版により変わるため、公式READMEで確認する。

## 手順

### Step 0：環境確認
PowerShell で次を実行してもらい、結果を確認する。
```powershell
node -v
npm -v
code --version
claude --version
```
- Node.js が無い、または LTS（推奨版）より古い → 公式サイト（nodejs.org）から LTS を入れてから再開
- `claude` が無い → Claude Code を導入してから再開（Claude Code 以外のクライアントを使う場合は Step 2 の mcp.json を使う）

### Step 2A：Claude Code に登録する場合（推奨）
PowerShell で次を実行する。Windows では `cmd /c` を挟む。
```powershell
claude mcp add playwright -- cmd /c npx @playwright/mcp@latest
```
- 全プロジェクトで使う場合は `--scope user` を付ける
- 登録確認：`claude mcp list`
- Windows警告の確認：Claude Code 内で `/doctor` を実行し、「Windows requires 'cmd /c' wrapper」の警告が出ていないか確認する
- Claude Code 内で `/mcp` を入力し、`playwright` が接続済みか確認する

### Step 2B：VSCode の GitHub Copilot（エージェントモード）で使う場合
プロジェクト直下に `.vscode/mcp.json` を作成する（既存があれば `servers` に追記するだけにする）。
```json
{
  "servers": {
    "playwright": {
      "type": "stdio",
      "command": "cmd",
      "args": ["/c", "npx", "@playwright/mcp@latest"]
    }
  }
}
```
- 追加後、VSCode の MCP 一覧（コマンドパレットで「MCP: List Servers」）で `playwright` が起動しているか確認する

### Step 3：ブラウザの準備
初回はブラウザ本体が必要になる場合がある。PowerShell で次を実行する。
```powershell
npx playwright install chromium
```
- 完了後、Step 4 の動作確認に進む

### Step 4：動作確認（1回だけ実行）
AIに次のように依頼して、ブラウザが開き、ページの見出しを返すか確認する。
「https://example.com を開いて、見出しのテキストを教えて」
- 成功：ブラウザが開き、見出しが返る → 導入完了
- 失敗：Step 5 へ

### Step 5：よくあるトラブル
| 症状 | 原因の候補 | 対処 |
|---|---|---|
| `npx` が見つからない | Node.js 未導入、PATH未反映 | PowerShell を開き直す。`node -v` を再確認 |
| 起動直後に終了する | `npx` 直接実行の問題 | Step 2A/2B の `cmd /c` 形式を使う |
| `playwright` が一覧にない | mcp.json の書式ミス、JSONの末尾カンマ | JSONを検証し、VSCode を再読み込み |
| ブラウザが起動しない | ブラウザ未インストール | Step 3 を実行 |
| 社内プロキシで失敗 | 通信制限 | 情シスに確認。通信許可の要否を案内 |

## 運用上の注意
- **セッション永続化**：ログイン状態やCookieが残るため、共有PCでは作業後に不要なセッションを削除する
- **機密情報**：パスワードや個人情報をプロンプトに書かない。社内サイトは許可を得た範囲でのみ操作する
- **ヘッドレス**：画面を出さずに実行したい場合は引数に `--headless` を追加する。画面を見て確認したい場合は付けない
- **外部サイト操作**：他社サイトの自動操作は利用規約を確認してから行う

## 禁止事項
- 既存の mcp.json や設定を確認なしに上書きすること
- 公式に無いオプションや推測のコマンドを案内すること（不明な場合は「要確認」と書く）
- パスワードや認証情報を手順の中に書くこと
