# corporate-training-lecture-builder（法人研修レベル 講義作成Skill）

企業が発注する品質の研修・講義を、ヒアリングから教材一式・効果測定計画まで一貫して設計するSkillです。うさうさ研修工房。

## 同梱物
- `corporate-training-lecture-builder.skill` … Claudeにアップロードするパッケージ
- `corporate-training-lecture-builder/` … 展開済みフォルダ
  - `SKILL.md` ワークフローと品質ゲート
  - `references/instructional-design.md` 動詞表・ブルーム・ガニェ・ARCS・カークパトリック・学習科学の根拠と限界
  - `assets/hearing_sheet.md` ヒアリングシート
  - `assets/course_design.template.yaml` 設計YAML雛形
  - `assets/quality_checklist.md` 品質ゲート採点表
  - `scripts/validate_design.py` 設計の整合性検査

## 使い方
1. `.skill` をアップロード。
2. 「◯◯研修を法人品質で作って。対象は…、時間は…」と依頼。
3. 流れ: ヒアリング → 目標設計 → 教授設計 → 設計YAML検査 → **設計の承認** → 教材一式 → 品質ゲート判定
4. 設計の検査（単体実行）
```bash
pip install pyyaml
python scripts/validate_design.py course_design.yaml
```
FAIL=0で次へ。WARNは理由を書けば残せます。

## 「法人研修レベル」8条件
ニーズ起点／測定可能な目標／目標⇔演習⇔評価の整合／能動的学習時間／運用可能性／効果測定(L1〜L3、L4候補)／転移設計／講師が再現できる

## 標準の成果物
受講者用スライド(pptx)・講師ガイド(docx)・演習シート(docx)・確認テストと解説・アンケートと行動計画シート・効果測定計画書・（要望時）提案サマリ

## 検査スクリプトがチェックする項目
禁止動詞（理解する等）／ブルーム水準／合計時間／目標と演習・評価の対応／評価水準が目標以上か／講義比率・連続講義・休憩（設計上の目安）／ガニェ9事象の配置／L1〜L3計画／行動計画・上司関与・フォロー

## 限界
- 検査は形式的整合のみ。内容の正しさ・業務適合・面白さは人のレビューが必要です。
- 講義比率50%以下・連続講義20分などは根拠のある法則ではなく**設計上の目安**です（`--max-lecture-ratio` 等で変更可）。
- 引用する効果量・数値は原典を確認してください。業績への効果は研修単体では保証できません。
