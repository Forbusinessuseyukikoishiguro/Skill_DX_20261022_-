#!/usr/bin/env python3
"""研修設計YAMLの形式的整合を検査する。 使い方: python validate_design.py course_design.yaml [--json out.json]
FAIL=法人研修レベルを満たさない / WARN=設計上の目安から外れる(理由を書けば残してよい) / PASS
"""
import argparse, json, sys
import yaml

BLOOM = ["remember", "understand", "apply", "analyze", "evaluate", "create"]
BANNED = ["理解する", "知る", "把握する", "学ぶ", "意識する", "心がける", "分かる", "わかる", "習得する"]
GAGNE = ["attention", "objectives", "prior_knowledge", "present", "guidance", "practice", "feedback", "assessment", "transfer"]
ACTIVE = {"exercise", "discussion", "demo"}
LECTURE_LIKE = {"lecture"}
NON_BREAK = {"intro", "lecture", "demo", "exercise", "discussion", "test", "wrap"}

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("yaml"); ap.add_argument("--json")
    ap.add_argument("--max-lecture-run", type=int, default=20)   # 設計上の目安
    ap.add_argument("--max-lecture-ratio", type=float, default=0.5)  # 設計上の目安
    ap.add_argument("--max-no-break", type=int, default=90)
    a = ap.parse_args()
    d = yaml.safe_load(open(a.yaml, encoding="utf-8"))
    R = []  # (level, code, msg)
    def add(l, c, m): R.append((l, c, m))

    meta = d.get("meta") or {}; objs = d.get("objectives") or []; mods = d.get("modules") or []
    ass = d.get("assessments") or []; ev = d.get("evaluation") or {}; tr = d.get("transfer") or {}
    ids = {o["id"]: o for o in objs}

    # 1 目標
    if not 3 <= len(objs) <= 6: add("WARN", "OBJ-COUNT", f"目標が{len(objs)}個（目安3〜6）")
    for o in objs:
        txt = o.get("text", "") + o.get("verb", "")
        if any(b in txt for b in BANNED): add("FAIL", "OBJ-VERB", f"{o['id']}: 観察不能な動詞を含む（{[b for b in BANNED if b in txt]}）")
        if o.get("bloom") not in BLOOM: add("FAIL", "OBJ-BLOOM", f"{o['id']}: bloom は {BLOOM} のいずれか")
        if not o.get("verb"): add("FAIL", "OBJ-VERB", f"{o['id']}: verb（行動動詞）が未記入")

    # 2 時間
    total = sum(m.get("minutes", 0) for m in mods)
    if total != meta.get("duration_min"): add("FAIL", "TIME-SUM", f"モジュール合計{total}分 ≠ 総時間{meta.get('duration_min')}分")
    for m in mods:
        for oid in m.get("objectives", []):
            if oid not in ids: add("FAIL", "REF", f"{m['id']}: 未定義の目標 {oid}")

    # 3 整合性（目標⇔演習⇔評価）
    for oid, o in ids.items():
        act = [m for m in mods if oid in m.get("objectives", []) and m.get("type") in ACTIVE]
        if not act: add("FAIL", "ALIGN-ACT", f"{oid}: 対応する演習/討議/実演が無い（孤児目標）")
        asm = [x for x in ass if oid in x.get("objectives", [])]
        if not asm: add("FAIL", "ALIGN-ASM", f"{oid}: 対応する評価が無い")
        else:
            if all(BLOOM.index(x.get("bloom", "remember")) < BLOOM.index(o.get("bloom", "remember")) for x in asm if x.get("bloom") in BLOOM):
                add("FAIL", "ALIGN-LEVEL", f"{oid}: 評価の水準が目標（{o.get('bloom')}）より低い")
    for x in ass:
        if not any(oid in ids for oid in x.get("objectives", [])): add("FAIL", "ALIGN-ORPHAN", f"評価{x.get('id')}: 目標に紐づかない")
    for m in mods:
        if m.get("type") in ACTIVE and not m.get("objectives"): add("WARN", "ALIGN-ORPHAN", f"{m['id']}: 目標に紐づかない演習")

    # 4 能動的学習
    work = sum(m["minutes"] for m in mods if m.get("type") in NON_BREAK)
    lec = sum(m["minutes"] for m in mods if m.get("type") in LECTURE_LIKE)
    if work and lec / work > a.max_lecture_ratio: add("WARN", "LECTURE-RATIO", f"講義比率{lec/work:.0%} > 目安{a.max_lecture_ratio:.0%}（設計方針）")
    run = 0
    for m in mods:
        if m.get("type") in LECTURE_LIKE:
            run += m["minutes"]
            if run > a.max_lecture_run: add("WARN", "LECTURE-RUN", f"{m['id']}: 連続講義{run}分 > 目安{a.max_lecture_run}分（想起課題/ペア確認を挟む）")
        else: run = 0
    # 休憩
    cont = 0
    for m in mods:
        if m.get("type") == "break":
            if m["minutes"] < 5: add("WARN", "BREAK-SHORT", f"{m['id']}: 休憩{m['minutes']}分は短い（目安10分）")
            cont = 0
        else:
            cont += m["minutes"]
            if cont > a.max_no_break: add("WARN", "BREAK-MISSING", f"{m['id']}付近: 休憩なしで{cont}分連続")
    if work and lec == work: add("FAIL", "ACTIVE-NONE", "全て講義型で能動的学習が無い")

    # 5 ガニェ
    seen = {g for m in mods for g in m.get("gagne", [])}
    miss = [g for g in GAGNE if g not in seen]
    if miss: add("WARN", "GAGNE", f"9教授事象で未配置: {miss}")

    # 6 効果測定・転移
    for k in ("level1", "level2", "level3"):
        if not ev.get(k): add("FAIL", "EVAL", f"効果測定 {k} が未記入")
    if not ev.get("level4"): add("WARN", "EVAL4", "level4（業績指標候補）が未記入")
    if not tr.get("action_plan"): add("FAIL", "TRANSFER", "行動計画（action_plan）が無い")
    if not tr.get("manager_involvement"): add("WARN", "TRANSFER-MGR", "上司の関与が未設計（転移の主要因）")
    if not tr.get("followup"): add("WARN", "TRANSFER-FU", "フォロー（分散復習）が未設計")
    if not d.get("assumptions"): add("WARN", "ASSUMP", "仮定一覧が空（ヒアリング済みなら『なし』と明記）")

    c = {k: sum(1 for r in R if r[0] == k) for k in ("FAIL", "WARN")}
    for lvl, code, msg in sorted(R, key=lambda r: r[0] != "FAIL"): print(f"[{lvl}] {code}: {msg}")
    print(f"\n結果: FAIL={c['FAIL']} WARN={c['WARN']}  ->", "PASS（FAILなし）" if c["FAIL"] == 0 else "要修正")
    if a.json: json.dump([{"level": l, "code": c_, "msg": m} for l, c_, m in R], open(a.json, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    sys.exit(1 if c["FAIL"] else 0)

if __name__ == "__main__":
    main()
