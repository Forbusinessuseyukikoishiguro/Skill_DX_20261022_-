#!/usr/bin/env python3
"""承認されたIDだけを適用し、別名保存する（元ファイルは変更しない）。
使い方: python apply_fixes.py 対象.pptx findings.json --approve F001,F004 -o 対象_fixed.pptx
        --approve ALL / S / SA などの級指定も可（auto_fix=true のものだけ）
"""
import argparse, json, sys
from pptx.dml.color import RGBColor
from pptx.util import Emu
from dlib import *

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx"); ap.add_argument("findings")
    ap.add_argument("--approve", required=True); ap.add_argument("-o", "--out", required=True)
    a = ap.parse_args()
    if a.out == a.pptx:
        sys.exit("元ファイルへの上書きは禁止です。別名を指定してください。")
    data = json.load(open(a.findings, encoding="utf-8"))
    fs = {f["id"]: f for f in data["findings"]}
    tok = [t.strip().upper() for t in a.approve.split(",") if t.strip()]
    if tok == ["ALL"]: ids = [i for i, f in fs.items() if f["auto_fix"]]
    elif all(set(t) <= set("SABC") for t in tok):
        sel = set("".join(tok)); ids = [i for i, f in fs.items() if f["auto_fix"] and f["severity"] in sel]
    else: ids = tok
    prs = load(a.pptx)
    done, skipped = [], []
    for i in ids:
        f = fs.get(i)
        if not f: skipped.append((i, "存在しないID")); continue
        if not f["auto_fix"]: skipped.append((i, "自動修正不可(△)")); continue
        slide = prs.slides[f["slide"] - 1]
        sh = next((s for s in iter_shapes(slide.shapes) if s.shape_id == f["shape_id"]), None)
        if sh is None: skipped.append((i, "図形が見つからない")); continue
        fx = f["fix"]; op = fx["op"]
        try:
            if op == "set_fill":
                sh.fill.solid(); sh.fill.fore_color.rgb = RGBColor.from_string(fx["to"].lstrip("#"))
            elif op == "set_line":
                sh.line.color.rgb = RGBColor.from_string(fx["to"].lstrip("#"))
            elif op == "set_font":
                for p, r in runs_of(sh): r.font.color.rgb = RGBColor.from_string(fx["to"].lstrip("#"))
            elif op == "set_font_name":
                for p, r in runs_of(sh): r.font.name = fx["to"]
            elif op == "set_size_center":
                cx, cy = sh.left + sh.width // 2, sh.top + sh.height // 2
                nw, nh = int(fx["w"] * EMU_IN), int(fx["h"] * EMU_IN)
                sh.width, sh.height = nw, nh; sh.left, sh.top = cx - nw // 2, cy - nh // 2
            elif op == "set_position":
                sh.left = int(fx["left"] * EMU_IN); sh.top = int(fx["top"] * EMU_IN)
            else: skipped.append((i, f"未対応op {op}")); continue
            done.append(i)
        except Exception as e:
            skipped.append((i, f"適用失敗: {e}"))
    prs.save(a.out)
    print("applied:", done); print("skipped:", skipped); print("saved:", a.out, "(元ファイルは未変更)")

if __name__ == "__main__":
    main()
