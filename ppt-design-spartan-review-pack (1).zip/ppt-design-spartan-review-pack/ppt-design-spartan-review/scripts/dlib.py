"""共通ヘルパー（python-pptx）"""
from pptx import Presentation
from pptx.util import Emu
from pptx.enum.shapes import MSO_SHAPE_TYPE
from pptx.dml.color import RGBColor

EMU_IN = 914400.0

def inch(v):
    return None if v is None else round(v / EMU_IN, 3)

def iter_shapes(shapes, depth=0):
    for sh in shapes:
        yield sh
        if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from iter_shapes(sh.shapes, depth + 1)

def hex_of(color_fmt):
    """ColorFormat -> '#RRGGBB' / None。テーマ色等は 'THEME' を返す。"""
    try:
        if color_fmt is None or color_fmt.type is None:
            return None
        if color_fmt.type == 1:  # RGB
            return "#" + str(color_fmt.rgb).upper()
        return "THEME"
    except Exception:
        return None

def fill_hex(sh):
    try:
        f = sh.fill
        if f.type == 1:  # solid
            return hex_of(f.fore_color)
    except Exception:
        pass
    return None

def line_hex(sh):
    try:
        if sh.line.fill.type == 1:
            return hex_of(sh.line.color)
    except Exception:
        pass
    return None

def runs_of(sh):
    if not getattr(sh, "has_text_frame", False) or not sh.has_text_frame:
        return
    for p in sh.text_frame.paragraphs:
        for r in p.runs:
            if r.text.strip():
                yield p, r

def is_picture(sh):
    return sh.shape_type == MSO_SHAPE_TYPE.PICTURE

def has_text(sh):
    return getattr(sh, "has_text_frame", False) and sh.has_text_frame and sh.text_frame.text.strip() != ""

def is_icon_candidate(sh, max_in):
    if sh.shape_type == MSO_SHAPE_TYPE.GROUP:
        return False
    if sh.width is None or sh.height is None:
        return False
    w, h = sh.width / EMU_IN, sh.height / EMU_IN
    if max(w, h) > max_in or min(w, h) < 0.15:
        return False
    if is_picture(sh):
        return True
    return not has_text(sh) and sh.shape_type in (MSO_SHAPE_TYPE.AUTO_SHAPE, MSO_SHAPE_TYPE.FREEFORM)

def rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))

def dist(a, b):
    ra, rb = rgb(a), rgb(b)
    return sum((x - y) ** 2 for x, y in zip(ra, rb)) ** 0.5

def is_neutral(h):
    r, g, b = rgb(h)
    return r == g == b

def lum(h):
    def ch(c):
        c /= 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = rgb(h)
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)

def contrast(a, b):
    la, lb = lum(a), lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)

def slide_bg_hex(slide):
    try:
        f = slide.background.fill
        if f.type == 1:
            return hex_of(f.fore_color)
    except Exception:
        pass
    return None

def font_size_pt(run, paragraph=None):
    if run.font.size:
        return run.font.size.pt
    if paragraph is not None and paragraph.font.size:
        return paragraph.font.size.pt
    return None

def load(path):
    return Presentation(path)
