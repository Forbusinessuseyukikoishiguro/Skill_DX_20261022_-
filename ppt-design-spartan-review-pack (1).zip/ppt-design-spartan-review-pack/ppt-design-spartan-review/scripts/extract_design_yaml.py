#!/usr/bin/env python3
"""お手本PPT（または対象PPT自身）からデザイン観測値を抽出し、ルールYAMLを生成する。
使い方: python extract_design_yaml.py 手本.pptx -o design_rules.yaml [--self-inferred]
注意: 観測=事実。お手本自体のブレも拾うので、出力は必ず人が確認してから基準にする。
"""
import argparse, statistics
from collections import Counter
import yaml
from dlib import *

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx")
    ap.add_argument("-o", "--out", default="design_rules.yaml")
    ap.add_argument("--self-inferred", action="store_true", help="対象PPT自身から推定（基準C）")
    ap.add_argument("--icon-max", type=float, default=1.2)
    a = ap.parse_args()

    prs = load(a.pptx)
    W, H = inch(prs.slide_width), inch(prs.slide_height)
    colors, fonts, sizes = Counter(), Counter(), Counter()
    icon_sizes, theme_cnt = [], 0
    lefts, tops, rights, bottoms = [], [], [], []
    title_boxes = []
    n_shapes = 0

    for si, slide in enumerate(prs.slides, 1):
        bg = slide_bg_hex(slide)
        if bg and bg != "THEME":
            colors[bg] += 1
        for sh in iter_shapes(slide.shapes):
            n_shapes += 1
            for h in (fill_hex(sh), line_hex(sh)):
                if h == "THEME": theme_cnt += 1
                elif h: colors[h] += 1
            for p, r in runs_of(sh):
                h = hex_of(r.font.color) if r.font.color is not None else None
                if h == "THEME": theme_cnt += 1
                elif h: colors[h] += 1
                if r.font.name: fonts[r.font.name] += 1
                s = font_size_pt(r, p)
                if s: sizes[round(s, 1)] += 1
            if is_icon_candidate(sh, a.icon_max):
                icon_sizes.append((round(sh.width / EMU_IN, 2), round(sh.height / EMU_IN, 2)))
            if sh.width and sh.left is not None and sh.shape_type != MSO_SHAPE_TYPE.GROUP:
                lefts.append(sh.left / EMU_IN); tops.append(sh.top / EMU_IN)
                rights.append((sh.left + sh.width) / EMU_IN); bottoms.append((sh.top + sh.height) / EMU_IN)
        # タイトル（placeholder title があれば）
        try:
            t = slide.shapes.title
            if t is not None:
                title_boxes.append((inch(t.left), inch(t.top), inch(t.width), inch(t.height)))
        except Exception:
            pass

    top_colors = [c for c, _ in colors.most_common(12)]
    size_list = sorted(sizes, reverse=True)
    icon_med = None
    if icon_sizes:
        icon_med = round(statistics.median([max(w, h) for w, h in icon_sizes]), 2)

    def mode(vals):
        return Counter([tuple(v) for v in vals]).most_common(1)[0][0] if vals else None
    tb = mode(title_boxes)

    rules = {
        "meta": {"name": a.pptx.split("/")[-1], "version": "auto-extracted",
                 "source": "self_inferred" if a.self_inferred else "reference_pptx",
                 "note": "観測値。人が確認・修正してから基準にすること"},
        "slide": {"width_in": W, "height_in": H,
                  "safe_margin_in": {"left": round(max(0.3, min(lefts)), 2) if lefts else None,
                                     "right": round(max(0.3, W - max(rights)), 2) if rights else None,
                                     "top": round(max(0.3, min(tops)), 2) if tops else None,
                                     "bottom": round(max(0.3, H - max(bottoms)), 2) if bottoms else None}},
        "palette": {f"c{i+1:02d}": c for i, c in enumerate(top_colors)},
        "palette_tolerance": {"near_match_distance": 12, "allow_neutrals": True},
        "fonts": {"allowed": [f for f, _ in fonts.most_common(3)]},
        "type_scale_pt": {"observed_sizes_desc": size_list[:10],
                          "title": size_list[0] if size_list else None,
                          "body": Counter(sizes).most_common(1)[0][0] if sizes else None,
                          "tolerance": 1, "min_body": 14, "min_any": 12},
        "contrast": {"normal_min": 4.5, "large_min": 3.0},
        "icons": {"size_in": icon_med, "tolerance_in": 0.03, "max_size_in": a.icon_max,
                  "observed_count": len(icon_sizes)},
        "layout": {"title_box": dict(zip(["left", "top", "width", "height"], tb)) if tb else None,
                   "title_tolerance_in": 0.05, "align_tolerance_in": 0.04, "align_near_miss_min_in": 0.005},
        "density": {"max_chars_per_slide": 250, "max_bullets_per_box": 5},
        "accessibility": {"require_alt_text_for_pictures": True},
        "_extraction_report": {"slides": len(prs.slides), "shapes": n_shapes,
                               "theme_or_unresolved_colors": theme_cnt,
                               "color_usage": dict(colors.most_common(20)),
                               "font_usage": dict(fonts.most_common(10))},
    }
    with open(a.out, "w", encoding="utf-8") as f:
        yaml.safe_dump(rules, f, allow_unicode=True, sort_keys=False)
    print(f"wrote {a.out}  slides={len(prs.slides)} shapes={n_shapes} theme/unresolved={theme_cnt}")

if __name__ == "__main__":
    main()
