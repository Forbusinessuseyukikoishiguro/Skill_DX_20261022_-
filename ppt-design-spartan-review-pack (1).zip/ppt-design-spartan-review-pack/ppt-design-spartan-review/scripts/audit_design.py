#!/usr/bin/env python3
"""PPTをルールYAMLと突き合わせ、事実ベースの指摘(findings.json)を出す。pptxは変更しない。
使い方: python audit_design.py 対象.pptx --rules design_rules.yaml -o findings.json
"""
import argparse, json, statistics
from collections import defaultdict
import yaml
from dlib import *

SEV_ORDER = {"S": 0, "A": 1, "B": 2, "C": 3}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pptx"); ap.add_argument("--rules", required=True)
    ap.add_argument("-o", "--out", default="findings.json")
    a = ap.parse_args()
    R = yaml.safe_load(open(a.rules, encoding="utf-8"))
    prs = load(a.pptx)
    F = []; cov = {"shapes": 0, "unresolved_color": 0}

    def add(sev, axis, slide, sh, title, evidence, basis, suggestion, fix=None):
        F.append({"severity": sev, "axis": axis, "slide": slide,
                  "shape_id": getattr(sh, "shape_id", None), "shape_name": getattr(sh, "name", None),
                  "title": title, "evidence": evidence, "basis": basis,
                  "suggestion": suggestion, "auto_fix": fix is not None, "fix": fix})

    pal = {k: v.upper() for k, v in (R.get("palette") or {}).items() if isinstance(v, str)}
    palset = set(pal.values())
    tol = R.get("palette_tolerance") or {}
    near = tol.get("near_match_distance", 12)
    allow_neutral = tol.get("allow_neutrals", True)
    fonts_ok = set((R.get("fonts") or {}).get("allowed") or [])
    ts = R.get("type_scale_pt") or {}
    ic = R.get("icons") or {}
    lay = R.get("layout") or {}
    sm = (R.get("slide") or {}).get("safe_margin_in") or {}
    W, H = inch(prs.slide_width), inch(prs.slide_height)
    ct = R.get("contrast") or {}
    dens = R.get("density") or {}
    acc = R.get("accessibility") or {}

    def check_color(slide, sh, hexv, where, kind):
        if hexv is None: return
        if hexv == "THEME":
            cov["unresolved_color"] += 1; return
        if not palset: return
        if hexv in palset: return
        if allow_neutral and is_neutral(hexv): return
        nearest = min(palset, key=lambda p: dist(hexv, p))
        d = round(dist(hexv, nearest), 1)
        if d <= near:
            add("B", "色", slide, sh, "近似色の混入", f"{where}={hexv}（最近傍 {nearest} と距離{d}）",
                "一貫性/ゲシュタルト(類似)・デジタル庁:色トークン固定", f"{nearest}へ統一",
                {"op": f"set_{kind}", "to": nearest})
        else:
            add("A", "色", slide, sh, "パレット外の色", f"{where}={hexv}（最近傍 {nearest} と距離{d}）",
                "一貫性・デジタル庁:色の用途固定", f"パレット色へ置換（候補 {nearest}）または意図的ならルールに追加")

    icons_by_slide = []
    titles = []
    for si, slide in enumerate(prs.slides, 1):
        bg = slide_bg_hex(slide) or (pal.get("background") or "#FFFFFF")
        total_chars = 0
        for sh in iter_shapes(slide.shapes):
            cov["shapes"] += 1
            fh, lh = fill_hex(sh), line_hex(sh)
            check_color(si, sh, fh, "塗り", "fill"); check_color(si, sh, lh, "線", "line")
            shape_bg = fh if fh and fh != "THEME" else bg
            for p, r in runs_of(sh):
                total_chars += len(r.text)
                col = hex_of(r.font.color) if r.font.color is not None else None
                check_color(si, sh, col, "文字色", "font")
                size = font_size_pt(r, p)
                fn = r.font.name
                if fonts_ok and fn and fn not in fonts_ok:
                    add("A", "文字", si, sh, "許可外フォント", f"'{fn}' / 許可={sorted(fonts_ok)}",
                        "一貫性・少数書体に固定", "許可フォントへ変更", {"op": "set_font_name", "to": sorted(fonts_ok)[0]})
                if size:
                    mn = ts.get("min_any")
                    if mn and size < mn:
                        add("S", "文字", si, sh, "文字が小さすぎる", f"{size}pt < 下限{mn}pt（'{r.text[:20]}'）",
                            "HCD:閲覧環境/WCAG可読性", f"{mn}pt以上へ。入らないなら文量を削る（拡大だけで溢れさせない）")
                if col and col != "THEME" and shape_bg != "THEME":
                    ratio = contrast(col, shape_bg)
                    large = (size or 0) >= 18
                    need = ct.get("large_min", 3.0) if large else ct.get("normal_min", 4.5)
                    if ratio < need:
                        add("S", "色", si, sh, "コントラスト不足", f"{col} on {shape_bg} = {ratio:.2f}:1 < {need}:1",
                            "WCAG 1.4.3・デジタル庁:コントラスト", "文字色か背景色を変更（背景が画像/グラデなら目視確認）")
            if is_picture(sh) and acc.get("require_alt_text_for_pictures"):
                descr = sh._element.xpath(".//p:cNvPr")[0].get("descr") if sh._element.xpath(".//p:cNvPr") else None
                if not descr:
                    add("B", "情報設計・到達性", si, sh, "代替テキスト欠落", "descr未設定", "WCAG 1.1.1・デジタル庁:アクセシビリティ",
                        "意味を持つ画像は説明を付与（装飾なら装飾指定）。内容は人が決める")
            # 余白
            if sh.left is not None and sh.width and sh.shape_type != MSO_SHAPE_TYPE.GROUP:
                L, T = sh.left / EMU_IN, sh.top / EMU_IN
                Rr, B = (sh.left + sh.width) / EMU_IN, (sh.top + sh.height) / EMU_IN
                full = (sh.width / EMU_IN) > W * 0.95 and (sh.height / EMU_IN) > H * 0.95
                if not full:
                    for side, val, lim, cmp in (("左", L, sm.get("left"), lambda v, l: v < l - 0.01),
                                                ("上", T, sm.get("top"), lambda v, l: v < l - 0.01),
                                                ("右", W - Rr, sm.get("right"), lambda v, l: v < l - 0.01),
                                                ("下", H - B, sm.get("bottom"), lambda v, l: v < l - 0.01)):
                        if lim is not None and cmp(val, lim):
                            add("B", "レイアウト・配置", si, sh, f"セーフエリア逸脱({side})",
                                f"{side}余白 {val:.2f}in < 基準{lim}in", "ゲシュタルト(余白)・投影時の見切れ防止",
                                "セーフエリア内へ移動/縮小（△:内容により人判断）")
        if total_chars > (dens.get("max_chars_per_slide") or 10**9):
            add("A", "情報設計・到達性", si, None, "文字量過多", f"{total_chars}字 > {dens['max_chars_per_slide']}字",
                "認知負荷理論・Mayer一貫性原則", "分割/要点化/図化（人判断）")
        # タイトル位置
        try:
            t = slide.shapes.title
            if t is not None and t.left is not None:
                titles.append((si, t, (t.left / EMU_IN, t.top / EMU_IN)))
        except Exception:
            pass
        icons_by_slide.append((si, [s for s in iter_shapes(slide.shapes) if is_icon_candidate(s, ic.get("max_size_in", 1.2))]))

    # アイコン寸法
    allicons = [(si, s) for si, lst in icons_by_slide for s in lst]
    if allicons:
        ref = ic.get("size_in") or statistics.median([max(s.width, s.height) / EMU_IN for _, s in allicons])
        tolin = ic.get("tolerance_in", 0.03)
        for si, s in allicons:
            w, h = s.width / EMU_IN, s.height / EMU_IN
            if abs(max(w, h) - ref) > tolin:
                add("A", "図形・アイコン", si, s, "アイコン寸法の不統一", f"{w:.2f}x{h:.2f}in / 基準{ref:.2f}in(許容±{tolin})",
                    "一貫性・ゲシュタルト(類似)", "基準寸法へ統一（中心を保持）",
                    {"op": "set_size_center", "w": round(ref * (w / max(w, h)), 3), "h": round(ref * (h / max(w, h)), 3)})
            if abs(w - h) > 0.02 and abs(max(w, h) - ref) <= tolin:
                add("C", "図形・アイコン", si, s, "アイコンが非正方形", f"{w:.2f}x{h:.2f}in", "縦横比の歪み防止", "縦横比を確認（人判断）")

    # タイトル位置ブレ
    tb = lay.get("title_box"); ttol = lay.get("title_tolerance_in", 0.05)
    if titles:
        refx = tb["left"] if tb else statistics.median([x for _, _, (x, y) in titles])
        refy = tb["top"] if tb else statistics.median([y for _, _, (x, y) in titles])
        for si, t, (x, y) in titles:
            if abs(x - refx) > ttol or abs(y - refy) > ttol:
                add("B", "レイアウト・配置", si, t, "タイトル位置のブレ", f"({x:.2f},{y:.2f})in / 基準({refx:.2f},{refy:.2f})",
                    "一貫性・視線起点の固定", "基準位置へ移動", {"op": "set_position", "left": round(refx, 3), "top": round(refy, 3)})

    # ニアミス整列（スライド内の左端）
    amax = lay.get("align_tolerance_in", 0.04); amin = lay.get("align_near_miss_min_in", 0.005)
    for si, slide in enumerate(prs.slides, 1):
        xs = [(s.left / EMU_IN, s) for s in iter_shapes(slide.shapes)
              if s.left is not None and s.shape_type != MSO_SHAPE_TYPE.GROUP and s.width and s.width / EMU_IN < W * 0.95]
        xs.sort(key=lambda t: t[0])
        for (x1, s1), (x2, s2) in zip(xs, xs[1:]):
            d = x2 - x1
            if amin <= d <= amax:
                add("B", "レイアウト・配置", si, s2, "左端のニアミス(ズレ)", f"'{s1.name}'x={x1:.3f} と '{s2.name}'x={x2:.3f} 差{d:.3f}in",
                    "ゲシュタルト(連続)・整列", f"x={x1:.3f}に揃える（意図的な段差でないか確認）",
                    {"op": "set_position", "left": round(x1, 3), "top": round(s2.top / EMU_IN, 3)})

    F.sort(key=lambda f: (SEV_ORDER[f["severity"]], f["slide"], f["axis"]))
    for i, f in enumerate(F, 1): f["id"] = f"F{i:03d}"
    out = {"file": a.pptx, "rules": a.rules, "coverage": cov, "counts": {k: sum(1 for f in F if f["severity"] == k) for k in "SABC"},
           "findings": F}
    json.dump(out, open(a.out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
    print(f"findings={len(F)} {out['counts']} unresolved_theme_colors={cov['unresolved_color']} -> {a.out}")

if __name__ == "__main__":
    main()
