# ppt-design-spartan-review（PPTデザイン統一スパルタレビューSkill）

「世界一のデザイナー」ペルソナで、PPT（.pptx）のデザイン統一性を厳しくレビューし、改善提案を出し、**許可を得てから**修正するSkillです。うさうさ研修工房。

## 同梱物
```
ppt-design-spartan-review-pack/
├── README.md                          ← このファイル
├── ppt-design-spartan-review.skill    ← Claudeに登録するパッケージ
└── ppt-design-spartan-review/         ← 同じ内容の展開済みフォルダ
    ├── SKILL.md                       ← Skill本体（ワークフロー・ルール）
    ├── references/
    │   ├── review-framework.md        ← 人間中心設計/デジタル庁/認知科学の観点と根拠
    │   └── report-template.md         ← レポート様式・採点基準
    ├── assets/
    │   └── design_rules.template.yaml ← デザインルールYAMLの雛形
    └── scripts/
        ├── dlib.py                    ← 共通ヘルパー
        ├── extract_design_yaml.py     ← お手本PPT → ルールYAML
        ├── audit_design.py            ← 機械監査（事実の洗い出し）
        └── apply_fixes.py             ← 承認IDだけを修正（別名保存）
```

## インストール
1. Claudeの「設定 → 機能（Skills）」で `ppt-design-spartan-review.skill` をアップロード（または保存ボタンから追加）。
2. 会話で次のように依頼します。メニュー位置は画面により異なります。

## 使い方
- 「このPPTのデザイン統一をスパルタレビューして」＋ .pptx を添付
- 基準は次のどれかを一緒に渡します（優先順位 A＞B＞C）
  - A. デザインルール文書（md/docx/pdf/txt/YAML）
  - B. お手本PPT
  - C. なし（対象PPT自身の最頻値から推定。その旨をレポートに明記）

### 流れ
1. 基準をYAML化 → **内容を確認してもらう**
2. 機械監査（色・フォント・文字サイズ・アイコン寸法・余白・整列・タイトル位置・コントラスト・文字量・代替テキスト）
3. 目視レビュー（人間中心設計・デジタル庁・認知科学）
4. スパルタレポート（100点満点、S/A/B/C級、ID付き指摘、良い点、統一担保の説明）
5. **承認ゲート**：修正するIDを指定するまで一切変更しない
6. 承認IDのみ修正 → `*_fixed.pptx` に別名保存 → 再監査で差分報告

### 承認の書き方
`F001, F004` / `S・A級すべて` / `全部` / `修正しない`
（自動修正可否が△の項目は提案のみ。手作業の手順を提示します）

## スクリプトを単体で使う場合
```bash
pip install python-pptx pyyaml
python scripts/extract_design_yaml.py 手本.pptx -o design_rules.yaml
python scripts/audit_design.py 対象.pptx --rules design_rules.yaml -o findings.json
python scripts/apply_fixes.py 対象.pptx findings.json --approve F001,F004 -o 対象_fixed.pptx
```
`--approve` は `ALL` や `S`、`SA` のような級指定も可（自動修正可能なもののみ）。元ファイルの上書きは拒否されます。

## 重大度
| 級 | 意味 | 減点 |
|---|---|---|
| S | 読めない/誤解/アクセシビリティ違反 | -5 |
| A | 統一性の明確な破綻 | -3 |
| B | 目に見えるブレ | -1 |
| C | 磨き込み | -0.5 |

5軸（色/文字/図形・アイコン/レイアウト・配置/情報設計・到達性）×20点。基準不在の項目は減点しません。

## 既知の限界
- テーマカラー・継承フォントは実値を解決できない場合があります（未解決として件数を報告）。
- 画像内の文字、SmartArt、OLEは機械検査不可（目視）。
- コントラストは単色塗り背景のときのみ判定。グラデーション/画像背景は目視。
- タイトル位置のブレは、タイトルプレースホルダーがあるPPTのみ機械検出。
- デジタル庁デザインシステムは改訂されるため、引用時は最新版を確認します（確認できない場合は「要最新確認」と明記）。
- 見落としゼロの保証はしません。カバレッジと限界はレポートに記載されます。

## 根拠の主な出典
ISO 9241-210（人間中心設計）／WCAG 2.x（1.4.1, 1.4.3, 1.4.11, 1.1.1）／JIS X 8341-3／デジタル庁デザインシステム／Sweller（認知負荷理論）／Cowan 2001（作業記憶約4チャンク）／Mayer（マルチメディア学習の原則）／ゲシュタルト原則／Nielsen（一貫性と標準）
