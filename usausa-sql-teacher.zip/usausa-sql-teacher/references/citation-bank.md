# 引用バンク（SQL学習・教え方の根拠）

検証状況
- 確認済: 2026-10-22 の検索で、論文の存在と書誌（題名・著者・掲載先）を確認。ただし本文の数値は未確認
- 要再確認: 著名な文献だが今回は検索で確認できていない。引用前に書誌を確認する

| ID | 書誌 | 使いどころ | 検証状況 |
|---|---|---|---|
| S-01 | Taipalus, T., Siponen, M., Vartiainen, T. (2018). Errors and Complications in SQL Query Formulation. ACM Transactions on Computing Education 18(3). | SQLの誤りを構文・意味・論理（＋複雑化）で分類する枠組み。添削の3分類の根拠 | 確認済（書誌のみ） |
| S-02 | Brass, S., Goldberg, C. (2006). Semantic errors in SQL queries: A quite complete list. Journal of Systems and Software 79(5). （前身: GVD 2004 ワークショップ論文） | 「動くが意味がおかしい」SQLの典型例リスト。誤りカタログの背景 | 確認済（書誌のみ。巻号は要確認） |
| S-03 | Ahadi, A., Prior, J., Behbood, V., Lister, R. (2016). Students' Syntactic Mistakes in Writing Seven Different Types of SQL Queries and its Application to Predicting Students' Success. ACM SIGCSE 2016. | 学習者の誤りがクエリの種類ごとに異なる。練習をクエリ型別に分ける根拠 | 確認済（書誌のみ） |
| S-04 | Ahadi, A., Behbood, V., Vihavainen, A., Prior, J., Lister, R. (2016). Students' Semantic Mistakes in Writing Seven Different Types of SQL Queries. ACM ITiCSE 2016. | 意味の誤り（論理の誤り）は構文エラーより見つけにくい。検証クエリを併記する根拠 | 確認済（書誌のみ） |
| S-05 | Miedema, D., Fletcher, G., Aivaloglou, E. (2022-2023). Expert Perspectives on Student Errors in SQL. ACM Transactions on Computing Education. | 教員の視点で見た学習者の誤りと、教え方への示唆 | 確認済（書誌のみ。巻号・年は要確認） |
| S-06 | Miedema, D., Aivaloglou, E., Fletcher, G. (2021). Identifying SQL Misconceptions of Novices: Findings from a Think-Aloud Study. ACM ICER 2021. | 初学者の誤解（ミスコンセプション）を発話思考で調べた研究。誤解を先回りして教える根拠 | 確認済（題名のみ。掲載先・年は要確認） |
| S-07 | Kalyuga, S., Ayres, P., Chandler, P., Sweller, J. (2003). The Expertise Reversal Effect. Educational Psychologist 38(1), 23-31. | 初心者に有効な支援が、経験者には逆効果になりうる。レベル別に説明量を変える根拠 | 要再確認 |
| S-08 | Sweller, J., Cooper, G.A. (1985). The Use of Worked Examples as a Substitute for Problem Solving in Learning Algebra. Cognition and Instruction 2(1), 59-89. | 初学者には「解き方つきの例」が有効。例を先に見せる根拠 | 要再確認 |
| S-09 | Reisner, P., Boyce, R.F., Chamberlin, D.D. (1975). Human Factors Evaluation of Two Data Base Query Languages: SQUARE and SEQUEL. AFIPS National Computer Conference. | SQLの前身SEQUELの人間工学評価。クエリ言語の使いやすさ研究の起点 | 確認済（IBM研究ページで存在確認。巻号は要確認） |
| S-10 | Codd, E.F. (1970). A Relational Model of Data for Large Shared Data Banks. CACM 13(6), 377-387. | 関係モデル。「表は集合」という見方の原点 | 要再確認 |

## 数値・主張の扱い

- 本ファイルは具体的な誤り率などの数値を載せていない。検索では題名・書誌しか確認できておらず、本文の数値は未確認のため。
- 数値を引用したいときは、原典の本文を読み、対象者（学部生など）・データ量・年を併記する。
- 「〜の研究では〜の傾向が報告された」と書き、「〜は常に〜だ」とは書かない。
- 学習者の誤りは、授業の課題や対象者に依存する。自分の受講生に当てはまるかは、受講生の答案で確かめる。
