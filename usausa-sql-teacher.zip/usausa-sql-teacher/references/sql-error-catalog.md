# よくある誤りカタログ

分類は S-01（Taipalus ほか）の「構文／意味／論理」に合わせる。背景は S-02〜S-06。
練習用3表（customers / orders / order_items）は lesson-ladder.md 参照。
各項目は「症状 → 原因 → 直し方 → 確認」の順で教える。

## 構文の誤り（エラーになる）

### E-01 GROUP BY にない列を SELECT した
- 症状: `column "order_date" must appear in the GROUP BY clause...` のようなエラー（PostgreSQL。他DBは文言が違う。MySQLの設定によっては通って不定の値になる）。
- 原因: グループ内で値が複数あり、どれを出すか決まらない。
- 直し方: GROUP BY に加える、または MIN/MAX など集計関数に入れる。
- 確認: 「このグループで、この列は1つに決まるか？」と自問する。

### E-02 WHERE に集計関数を書いた
- 症状: `aggregate functions are not allowed in WHERE`（PostgreSQL）。
- 原因: WHERE は集計の前に評価される。
- 直し方: HAVING に移す。

### E-03 列の別名を WHERE で使った
- 症状: 列が存在しないエラー。
- 原因: SELECT の別名は WHERE より後で決まる（処理順: FROM→WHERE→GROUP BY→HAVING→SELECT→ORDER BY）。別名は ORDER BY では使えることが多い。
- 直し方: 元の式を書くか、CTE/副問い合わせで包む。

### E-04 引用符・カンマ・括弧のミス
- 症状: syntax error near ...
- 直し方: エラー位置の「直前」を見る。文字列は `'…'`（シングル）。識別子の引用はDBごとに違う。長い式は括弧の対応を数える（S-06: 学習者は複雑さの管理で括弧に苦労する、という趣旨の研究あり。内容は要確認）。

### E-05 あいまいな列名
- 症状: `column reference "customer_id" is ambiguous`
- 原因: 結合した複数の表に同名の列がある。
- 直し方: `表の別名.列名` と必ず書く（c.customer_id）。

## 意味の誤り（動くが、常に意味がない）

### E-10 常に偽・常に真の条件
- 例: `WHERE amount > 5000 AND amount < 3000`（常に0行）。`WHERE x = 1 OR x <> 1`（NULLを除き常に真）。
- 確認: 条件を日本語に直して矛盾がないか読む。

### E-11 NULL との比較に = を使った
- 例: `WHERE city = NULL`（常に0行）。
- 直し方: `IS NULL` / `IS NOT NULL`。

### E-12 不要な DISTINCT・不要な GROUP BY
- 症状: 結果は合うが、重複の原因を隠している。
- 確認: DISTINCT を外して、重複する理由（結合の増殖など）を調べる。

## 論理の誤り（動く。でも依頼とズレる）— 最も見つけにくいので優先して疑う（S-04）

### E-20 1対多の結合による二重計上
- 例: orders と order_items を結合して SUM(o.amount)。サンプルデータで 14000（正しくは 11000）。
- 直し方: 先に明細側を集計してから結合／金額は注文表だけから合計。
- 確認: 結合前後の SUM が一致するか。

### E-21 INNER JOIN で行が消える
- 例: 注文のない顧客（田中）が「顧客ごとの売上」から消える。
- 直し方: 残したい側を LEFT JOIN。0にしたいなら COALESCE。

### E-22 LEFT JOIN の右表の条件を WHERE に書いた
- 例: `LEFT JOIN orders o ON ... WHERE o.order_date >= '2026-04-01'` → NULL行が落ち、実質 INNER JOIN になる。
- 直し方: 条件を ON に書く。

### E-23 NOT IN とサブクエリの NULL
- 例: `WHERE id NOT IN (SELECT parent_id FROM t)` で、サブクエリにNULLがあると結果が空。
- 直し方: NOT EXISTS、または LEFT JOIN … IS NULL。

### E-24 <> のNULL落ち
- 例: `city <> '東京'` は city が NULL の行を含まない。
- 直し方: `OR city IS NULL` を足すか、COALESCE で置換。

### E-25 日付の終端漏れ
- 例: `BETWEEN '2026-04-01' AND '2026-04-30'` は、時刻付き列で4/30の午後が漏れる。
- 直し方: `>= 開始 AND < 翌日`。

### E-26 COUNT(*) と COUNT(列) の取り違え
- 例: LEFT JOIN 後の COUNT(*) は、右表がなくても1と数える。
- 直し方: 右表の列で COUNT(o.order_id)。

### E-27 集計後に重複を数える／平均の平均
- 例: 顧客ごとの平均の平均は、全体平均と一致しない。
- 確認: 「どの粒度の平均か」を日本語で書き出す。

## 教え方のコツ（S-05, S-06 の考え方を踏まえて）

1. 間違いを見つけたら、まず「この間違いはよく起きる」と伝える。
2. 学習者の頭の中の誤解（例: 「WHEREで何でも絞れる」）を、1つ言葉にして確認する。
3. 反例を小さなデータで見せる（サンプルの田中が消える、など）。
4. 直した後、必ず検証クエリで数字を確かめさせる。
