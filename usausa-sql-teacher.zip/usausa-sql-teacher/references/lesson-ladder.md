# レッスン梯子（L0〜L8）

方言: 標準SQL寄り。SQLite・PostgreSQLで動く書き方にしてある（LIMIT を使う）。SQL Server は TOP、Oracle は FETCH FIRST に置換する。

## 練習用の3表（サンプルデータ）

```sql
CREATE TABLE customers (customer_id INTEGER PRIMARY KEY, name TEXT, city TEXT);
CREATE TABLE orders (order_id INTEGER PRIMARY KEY, customer_id INTEGER, order_date TEXT, amount INTEGER);
CREATE TABLE order_items (item_id INTEGER PRIMARY KEY, order_id INTEGER, product TEXT, qty INTEGER, price INTEGER);

INSERT INTO customers VALUES (1,'佐藤','東京'),(2,'鈴木','大阪'),(3,'高橋','東京'),(4,'田中',NULL);
INSERT INTO orders VALUES
 (101,1,'2026-04-01',3000),(102,1,'2026-04-15',2000),
 (103,2,'2026-04-20',5000),(104,3,'2026-05-02',1000);
INSERT INTO order_items VALUES
 (1,101,'ペン',10,100),(2,101,'ノート',5,400),
 (3,102,'ペン',20,100),(4,103,'ファイル',10,500),
 (5,104,'ペン',10,100);
```

顧客4（田中）は注文なし、都市もNULL。わざとJOINやNULLの練習になるようにしてある。

---

## L0 SELECT / FROM（表から列を取り出す）

- Why: まず「何が入っているか」を見たい。
- What: SELECT = 見たい列、FROM = どの表から。
- How:
```sql
SELECT name, city FROM customers;
```
1. SELECT name, city → 見たい列を並べる
2. FROM customers → 顧客表から
- つまずき: `SELECT *` は全列。確認には便利だが、業務の抽出では必要な列だけにする。
- 練習: 注文表から order_id と amount だけを出す。
- 答え: `SELECT order_id, amount FROM orders;`

## L1 WHERE（行を絞る）

- Why: 全部ではなく、条件に合う行だけが欲しい。
- What: WHERE = 行の絞り込み条件。
- How:
```sql
SELECT order_id, amount FROM orders WHERE amount >= 3000;
```
- 結果の期待: 101（3000）と103（5000）の2行。
- つまずき: 文字列は `'東京'` のように引用符で囲む。`=` は1つ。
- 練習: 2026年4月の注文を出す（日付は半開区間で）。
- 答え:
```sql
SELECT * FROM orders
WHERE order_date >= '2026-04-01' AND order_date < '2026-05-01';
```
- 解説: 「4/30以下」と書くと、時刻付きの列で4/30の午後が漏れる。「翌月1日未満」が安全。

## L2 ORDER BY / LIMIT（並べる・件数を絞る）

```sql
SELECT order_id, amount FROM orders ORDER BY amount DESC LIMIT 2;
```
- 期待: 103（5000）、101（3000）。
- DESC = 大きい順。省略すると昇順（ASC）。
- 方言: SQL Server は `SELECT TOP 2 ...`、Oracle は `FETCH FIRST 2 ROWS ONLY`。
- 練習: 金額が小さい順に3件。答え: `ORDER BY amount ASC LIMIT 3`（ASCは省略可）。

## L3 集計とGROUP BY（まとめて数える・足す）

- Why: 「顧客ごとの売上」のように、グループ単位の数字が欲しい。
- What: GROUP BY = グループ分け。SUM/COUNT/AVG/MIN/MAX = グループごとの計算。
- How:
```sql
SELECT customer_id, COUNT(*) AS 注文数, SUM(amount) AS 売上合計
FROM orders
GROUP BY customer_id;
```
- 期待: 顧客1は2件・5000、顧客2は1件・5000、顧客3は1件・1000。
- ルール: SELECT に書く列は、GROUP BY にあるか、集計関数の中にある。
- つまずき: `SELECT customer_id, order_date ... GROUP BY customer_id` はエラー（または不定の値）。order_date は「どの日？」が決まらない。
- 練習: 月ごとの売上合計。
- 答え（SQLite）:
```sql
SELECT substr(order_date,1,7) AS 年月, SUM(amount) AS 売上
FROM orders GROUP BY substr(order_date,1,7);
```
- PostgreSQLなら `date_trunc('month', order_date)`。方言を明記して教える。

## L4 HAVING（グループに条件をつける）

- 違い: WHERE は集計前の行を絞る。HAVING は集計後のグループを絞る。
```sql
SELECT customer_id, SUM(amount) AS 売上合計
FROM orders
GROUP BY customer_id
HAVING SUM(amount) >= 5000;
```
- 期待: 顧客1と顧客2。
- 処理順: FROM → WHERE → GROUP BY → HAVING → SELECT → ORDER BY。
- つまずき: `WHERE SUM(amount) >= 5000` はエラー。集計は WHERE の時点でまだ終わっていない。
- 練習: 注文が2件以上の顧客。答え: `HAVING COUNT(*) >= 2`

## L5 JOIN（表をつなぐ）

- Why: 注文表には顧客名がない。顧客表とつなぎたい。
- What: 共通の列（customer_id）で、行を対応づける。
- INNER JOIN: 両方にある行だけ。LEFT JOIN: 左の表は全部残す。
```sql
SELECT c.name, o.order_id, o.amount
FROM customers c
INNER JOIN orders o ON o.customer_id = c.customer_id;
```
- 期待: 注文のある顧客だけ4行（佐藤2、鈴木1、高橋1）。田中は注文がないので出ない。
```sql
SELECT c.name, o.order_id
FROM customers c
LEFT JOIN orders o ON o.customer_id = c.customer_id;
```
- 期待: 田中も出る（order_id は NULL）。
- 「注文のない顧客」を探す:
```sql
SELECT c.name
FROM customers c
LEFT JOIN orders o ON o.customer_id = c.customer_id
WHERE o.order_id IS NULL;
```
- 期待: 田中。
- つまずき（重要）: 1対多のJOINで行が増える。
```sql
-- 誤り: 注文金額が明細の行数ぶん二重計上される
SELECT SUM(o.amount) FROM orders o JOIN order_items i ON i.order_id = o.order_id;
```
- 期待: 注文101は明細2行なので3000が2回、注文102・103・104は1回ずつ。合計 = 3000×2 + 2000 + 5000 + 1000 = 14000（正しい合計は11000）。
- 直し方: 先に明細側を集計してから結合する、または金額は注文表だけから合計する。
- 練習: 顧客ごとの売上合計（名前つき、注文のない顧客は0）。
- 答え:
```sql
SELECT c.name, COALESCE(SUM(o.amount), 0) AS 売上合計
FROM customers c
LEFT JOIN orders o ON o.customer_id = c.customer_id
GROUP BY c.customer_id, c.name;
```

## L6 サブクエリ・CTE（問い合わせを部品にする）

- Why: 1回で書くと読めない。段階に分けたい。
- What: CTE（WITH句）= 名前をつけた中間結果。
```sql
WITH customer_sales AS (
  SELECT customer_id, SUM(amount) AS sales
  FROM orders
  GROUP BY customer_id
)
SELECT c.name, s.sales
FROM customers c
JOIN customer_sales s ON s.customer_id = c.customer_id
WHERE s.sales >= 5000;
```
- 期待: 佐藤（5000）、鈴木（5000）。
- 教え方: 「①顧客ごとに集計 → ②顧客名をつける → ③絞る」と日本語で先に書いてから、SQLにする。
- つまずき: `NOT IN (サブクエリ)` は、サブクエリの結果にNULLが含まれると結果が空になる。`NOT EXISTS` か LEFT JOIN … IS NULL を使う。

## L7 ウィンドウ関数（行を残したまま計算）

- Why: 行を潰さずに「顧客内の順位」「累計」を出したい。
- What: OVER (PARTITION BY 区切り ORDER BY 並び) = 窓を区切って計算。
```sql
SELECT order_id, customer_id, amount,
       ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY order_date DESC) AS rn
FROM orders;
```
- 最新1件だけ: これを副問い合わせで包み、`WHERE rn = 1`。
- 期待: 顧客1は102（4/15）が rn=1。
- 違い: GROUP BY は行を潰す。ウィンドウ関数は行を残す。
- 方言: 古い版では未対応。SQLiteは3.25以降、MySQLは8.0以降（要確認）。

## L8 NULL・日付・重複の罠（実務で一番事故る）

1. NULL は「不明」。`= NULL` は常に不明になり、行が出ない。`IS NULL` を使う。
2. 集計: `COUNT(*)` は行数、`COUNT(列)` はNULLを除いた数。
3. 比較: `city <> '東京'` は、cityがNULLの行を含まない（田中が出ない）。
```sql
SELECT name FROM customers WHERE city <> '東京';   -- 鈴木のみ。田中は出ない
SELECT name FROM customers WHERE city <> '東京' OR city IS NULL;  -- 鈴木、田中
```
4. 日付: 「以上〜未満」の半開区間。タイムゾーンも確認。
5. 重複: DISTINCT で消す前に、なぜ重複するか（結合の増殖など）を調べる。

---

## 教え方の注意（レベルが上がっても変えない）

1. 毎回、日本語の「言い換え文」→SQL→1句ずつの説明の順。
2. 期待結果は、このサンプルデータで手計算できる形で示す。
3. 学習者が詰まったら、ヒントを3段階（観点→部品→答え）で出す。
