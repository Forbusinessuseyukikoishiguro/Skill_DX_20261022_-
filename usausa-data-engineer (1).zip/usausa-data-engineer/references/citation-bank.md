# 引用バンク（査読済み論文）

検証状況の凡例
- 確認済: 2026-10-21 時点で検索により書誌・要旨を確認
- 要再確認: 著名な古典だが本作成時には再検索していない。引用前に書誌（巻号・ページ）を確認する

| ID | 書誌 | 使いどころ | 検証状況 |
|---|---|---|---|
| C-01 | Codd, E.F. (1970). A Relational Model of Data for Large Shared Data Banks. CACM 13(6), 377-387. | 関係モデルの原点。表・キー・データ独立性の説明 | 要再確認 |
| C-02 | Chen, P.P. (1976). The Entity-Relationship Model: Toward a Unified View of Data. ACM TODS 1(1), 9-36. | 概念設計・ER図 | 要再確認 |
| C-03 | Curino, C., Moon, H.J., Tanca, L., Zaniolo, C. (2008). Schema Evolution in Wikipedia: Toward a Web Information System Benchmark. ICEIS 2008. | スキーマ変更が多数のクエリに影響する根拠（1回の変更で最大約70%のクエリに影響） | 確認済 |
| C-04 | Curino, C., Moon, H.J., Deutsch, A., Zaniolo, C. (2013). Automating the database schema evolution process. The VLDB Journal 22, 73-98. DOI 10.1007/s00778-012-0302-x | 手作業のスキーマ移行は誤りやすい（Wikipediaの変更の18%超に検出可能な誤り） | 確認済 |
| C-05 | Berenson, H., Bernstein, P., Gray, J., Melton, J., O'Neil, E., O'Neil, P. (1995). A Critique of ANSI SQL Isolation Levels. ACM SIGMOD 1995, 1-10. DOI 10.1145/223784.223785 | 分離レベル・スナップショット分離・更新系SQLの競合 | 確認済 |
| C-06 | Wang, R.Y., Strong, D.M. (1996). Beyond Accuracy: What Data Quality Means to Data Consumers. J. Management Information Systems 12(4), 5-33. | データ品質の4分類（内在的・文脈的・表現的・アクセス性）、現状把握の品質観点 | 確認済 |
| C-07 | Li, J. et al. (2023). Can LLM Already Serve as A Database Interface? A BIg Bench for Large-Scale Database Grounded Text-to-SQLs (BIRD). NeurIPS 2023. | 依頼文→SQLで「値の汚れ・外部知識・効率」が難所である根拠。人手の検証が必要 | 確認済 |
| C-08 | Deng, X. et al. (2022). Recent Advances in Text-to-SQL: A Survey of What We Have and What We Expect. COLING 2022. arXiv:2208.10099 | Text-to-SQLの全体像・課題 | 確認済 |
| C-09 | Katsogiannis-Meimarakis, G., Xydas, M., Koutrika, G. (2023). Natural Language Interfaces for Databases with Deep Learning. PVLDB 16(12). | 自然言語DBインタフェースの整理（チュートリアル） | 確認済 |
| C-10 | Pourreza, M., Rafiei, D. (2023). DIN-SQL: Decomposed In-Context Learning of Text-to-SQL with Self-Correction. NeurIPS 2023. arXiv:2304.11015 | 複雑な依頼を分解してSQL化する手順の根拠 | 要再確認（検索結果内の言及のみ） |
| C-11 | Selinger, P.G. et al. (1979). Access Path Selection in a Relational Database Management System. ACM SIGMOD 1979. | オプティマイザ・コストベース最適化・EXPLAINの読み方の背景 | 要再確認 |
| C-12 | Fagin, R. (1977). Multivalued Dependencies and a New Normal Form for Relational Databases. ACM TODS 2(3). | 第4正規形・正規化理論 | 要再確認 |
| C-13 | Bayer, R., McCreight, E. (1972). Organization and Maintenance of Large Ordered Indexes. Acta Informatica 1, 173-189. | B-treeインデックスの原理 | 要再確認 |

## 数値を引用するときの注意

- C-03 の「最大約70%」は MediaWiki の変更履歴での観測。他システムに一般化しない。
- C-04 の「18%超」は Wikipedia の移行ステップでの観測。社内システムの誤り率を意味しない。
- C-07 はベンチマーク結果であり、自社DBでの精度保証ではない。生成SQLは必ず人が検証する。
- 引用時は「著者(年)の研究では〜が示された」と条件付きで書く。「〜と証明された」とは書かない。
