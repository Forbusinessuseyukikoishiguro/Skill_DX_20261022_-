# SQLテンプレ集

方言は PostgreSQL を基準に記載。他DBは「方言差メモ」を参照し、提示時に必ず置換する。

## A章 現状把握（読み取り専用）

### A-1 テーブル一覧と概算件数（PostgreSQL）
```sql
-- PostgreSQL / 読み取り専用 / 概算件数（統計情報ベース）
SELECT n.nspname AS schema_name, c.relname AS table_name, c.reltuples::bigint AS approx_rows
FROM pg_class c
JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind = 'r' AND n.nspname NOT IN ('pg_catalog','information_schema')
ORDER BY approx_rows DESC;
```

### A-2 列定義（標準 information_schema。多くのDBで使える）
```sql
SELECT table_schema, table_name, column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_schema = :schema AND table_name = :table
ORDER BY ordinal_position;
```

### A-3 主キー・外部キー・制約
```sql
SELECT tc.table_name, tc.constraint_type, tc.constraint_name, kcu.column_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
WHERE tc.table_schema = :schema
ORDER BY tc.table_name, tc.constraint_type, kcu.ordinal_position;
```

### A-4 NULL率・重複キー（品質確認。論文 C-06 の観点）
```sql
-- NULL率（列ごとに差し替え）
SELECT COUNT(*) AS total, COUNT(col) AS non_null,
       ROUND(100.0 * (COUNT(*) - COUNT(col)) / NULLIF(COUNT(*),0), 2) AS null_pct
FROM target_table;

-- 重複候補キー
SELECT key_col, COUNT(*) AS cnt
FROM target_table
GROUP BY key_col
HAVING COUNT(*) > 1
ORDER BY cnt DESC;
```

### A-5 孤児レコード（外部キー整合）
```sql
SELECT c.*
FROM child c
LEFT JOIN parent p ON p.id = c.parent_id
WHERE c.parent_id IS NOT NULL AND p.id IS NULL;
```

### A-6 遅いクエリ上位（PostgreSQL / pg_stat_statements 有効時）
```sql
-- 列名はバージョンで異なる（PG13以降は total_exec_time / mean_exec_time）。公式で要確認
SELECT query, calls, total_exec_time, mean_exec_time, rows
FROM pg_stat_statements
ORDER BY total_exec_time DESC
LIMIT 20;
```

### A-7 テーブル/インデックス容量（PostgreSQL）
```sql
SELECT relname, pg_size_pretty(pg_total_relation_size(relid)) AS total_size
FROM pg_catalog.pg_statio_user_tables
ORDER BY pg_total_relation_size(relid) DESC
LIMIT 20;
```

## C章 抽出の型

### C-1 期間集計（日付境界は半開区間）
```sql
SELECT date_trunc('month', order_date) AS ym, COUNT(*) AS orders, SUM(amount) AS sales
FROM orders
WHERE order_date >= DATE '2026-01-01' AND order_date < DATE '2026-04-01'
GROUP BY 1
ORDER BY 1;
```

### C-2 最新1件（ウィンドウ関数）
```sql
SELECT *
FROM (
  SELECT t.*, ROW_NUMBER() OVER (PARTITION BY customer_id ORDER BY updated_at DESC) AS rn
  FROM customers_history t
) x
WHERE rn = 1;
```

### C-3 1対多結合での二重計上回避
```sql
-- 先に子テーブルを集約してから結合する
WITH item_sum AS (
  SELECT order_id, SUM(price * qty) AS item_total
  FROM order_items
  GROUP BY order_id
)
SELECT o.order_id, o.customer_id, i.item_total
FROM orders o
LEFT JOIN item_sum i ON i.order_id = o.order_id;
```

### C-4 突合（2つの抽出結果の差分）
```sql
SELECT 'A_only' AS side, a.id FROM a LEFT JOIN b ON b.id = a.id WHERE b.id IS NULL
UNION ALL
SELECT 'B_only', b.id FROM b LEFT JOIN a ON a.id = b.id WHERE a.id IS NULL;
```

## E章 安全なDML・DDLの型

### E-1 更新前の確認 → トランザクション更新
```sql
-- 1) 対象件数を確認（報告に載せる）
SELECT COUNT(*) FROM target WHERE <条件>;

-- 2) バックアップ（検証環境で確認済みの方法に従う）
-- CREATE TABLE target_bk_YYYYMMDD AS SELECT * FROM target WHERE <条件>;

-- 3) 更新（実行前に必ずレビュー）
BEGIN;
UPDATE target SET col = :new_value WHERE <条件>;
-- 件数が1)と一致するか確認。違えば ROLLBACK;
COMMIT;
```

### E-2 列追加の段階リリース
```sql
-- Step1: NULL許容で追加（既存クエリに影響しない）
ALTER TABLE t ADD COLUMN new_col text;
-- Step2: バッチで埋める（小分け・負荷に注意）
-- Step3: アプリ切替後に NOT NULL / 既定値 / 制約を付与
-- Step4: 旧列の削除は十分な観察期間後（ロールバック手順を先に用意）
```

## 方言差メモ

| 項目 | PostgreSQL | MySQL | SQL Server | Oracle |
|---|---|---|---|---|
| 行数制限 | LIMIT n | LIMIT n | TOP n / OFFSET FETCH | FETCH FIRST n ROWS ONLY |
| 文字列連結 | \|\| | CONCAT() | + / CONCAT() | \|\| |
| 現在日時 | now() | NOW() | SYSDATETIME() | SYSTIMESTAMP |
| 月初 | date_trunc('month', d) | DATE_FORMAT 等 | DATETRUNC（新しい版）/ EOMONTH 等 | TRUNC(d,'MM') |
| 実行計画 | EXPLAIN | EXPLAIN | 実行プラン表示 | EXPLAIN PLAN |

提示時は対象DBに合わせて置換し、バージョン依存は「要確認」と書く。
