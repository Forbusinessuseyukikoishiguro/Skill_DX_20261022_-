# 公式ドキュメント集

最新版・サポート版は必ず公式サイトで確認する（バージョンで構文・挙動が変わる）。
確認状況: 「確認済」は 2026-10-21 に検索結果で実在を確認。それ以外はトップページ単位の記載で、個別ページURLは公式サイト内検索で再確認する。

## PostgreSQL（公式: https://www.postgresql.org/docs/）

- EXPLAIN: https://www.postgresql.org/docs/current/sql-explain.html（確認済）
- Using EXPLAIN（読み方）: https://www.postgresql.org/docs/current/using-explain.html（確認済）
- pg_stat_statements: https://www.postgresql.org/docs/current/pgstatstatements.html（確認済）
- 要点: EXPLAIN ANALYZE は実際に実行される。更新系は BEGIN … ROLLBACK で囲む。

## MySQL

- リファレンスマニュアル: https://dev.mysql.com/doc/
- 見る場所: EXPLAIN出力、InnoDBロック、information_schema

## SQL Server

- Microsoft Learn（日本語あり）: https://learn.microsoft.com/ja-jp/sql/
- 見る場所: 実行プラン、DMV（sys.dm_*）、インデックス設計ガイド

## Oracle Database

- 公式ドキュメント: https://docs.oracle.com/en/database/
- 見る場所: SQL Language Reference、Performance Tuning Guide

## SQLite

- 公式: https://www.sqlite.org/docs.html
- 見る場所: データ型（型アフィニティ）、EXPLAIN QUERY PLAN

## クラウドDWH

- BigQuery: https://cloud.google.com/bigquery/docs
- Snowflake: https://docs.snowflake.com/
- 見る場所: パーティション/クラスタリング、課金（スキャン量）、方言差

## 標準

- SQL標準: ISO/IEC 9075（有償）。国内規格は JIS X 3005 シリーズ。
- 標準にない機能（例: EXPLAIN）はベンダー拡張。PostgreSQL公式も標準未定義と明記。

## データ品質の規格

- ISO/IEC 25012（データ品質モデル）、ISO 8000。詳細運用は usausa-csv-quality-kaizen を参照。
